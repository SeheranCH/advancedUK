package ch.course223.advanced.UK;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UkApplication {

	public static void main(String[] args) {
		SpringApplication.run(UkApplication.class, args);
	}

}
